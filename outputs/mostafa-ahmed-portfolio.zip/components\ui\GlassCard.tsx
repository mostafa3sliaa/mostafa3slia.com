"use client";

import { motion } from "framer-motion";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { hoverLift } from "@/lib/motion";
import { cn } from "@/lib/utils";

type GlassCardProps = ComponentPropsWithoutRef<typeof motion.div> & {
  children: ReactNode;
  glow?: boolean;
};

export function GlassCard({ children, className, glow = true, ...props }: GlassCardProps) {
  return (
    <motion.div
      whileHover={hoverLift}
      className={cn(
        "group relative overflow-hidden rounded-[8px] border border-white/12 bg-white/[0.055] p-6 shadow-2xl shadow-black/25 backdrop-blur-2xl",
        glow && "before:absolute before:inset-px before:rounded-[7px] before:bg-gradient-to-br before:from-white/10 before:to-transparent before:opacity-0 before:transition-opacity before:duration-300 hover:before:opacity-100",
        "after:absolute after:left-1/2 after:top-0 after:h-px after:w-1/2 after:-translate-x-1/2 after:bg-gradient-to-r after:from-transparent after:via-white/35 after:to-transparent",
        className,
      )}
      {...props}
    >
      <div className="relative z-10">{children}</div>
    </motion.div>
  );
}
