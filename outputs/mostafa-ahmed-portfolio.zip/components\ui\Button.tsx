"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import type { IconType } from "react-icons";
import { FiArrowRight } from "react-icons/fi";
import { cn } from "@/lib/utils";

type ButtonProps = {
  href: string;
  children: React.ReactNode;
  icon?: IconType;
  variant?: "primary" | "secondary";
  className?: string;
};

export function Button({ href, children, icon: Icon = FiArrowRight, variant = "primary", className }: ButtonProps) {
  return (
    <motion.div whileHover={{ y: -3, scale: 1.02 }} whileTap={{ scale: 0.98 }}>
      <Link
        href={href}
        className={cn(
          "focus-ring inline-flex min-h-12 items-center justify-center gap-2 rounded-[8px] border px-5 text-sm font-semibold transition duration-300",
          variant === "primary"
            ? "border-blue-300/30 bg-white text-black shadow-[0_0_44px_rgba(96,165,250,0.22)] hover:bg-blue-50"
            : "border-white/12 bg-white/[0.06] text-white backdrop-blur-xl hover:border-white/24 hover:bg-white/[0.1]",
          className,
        )}
      >
        <span>{children}</span>
        <Icon aria-hidden className="size-4" />
      </Link>
    </motion.div>
  );
}
