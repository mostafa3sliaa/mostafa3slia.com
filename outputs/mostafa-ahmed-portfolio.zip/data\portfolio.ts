import {
  FiBarChart2,
  FiBriefcase,
  FiCode,
  FiGithub,
  FiGlobe,
  FiLinkedin,
  FiMail,
  FiMapPin,
  FiMessageCircle,
  FiNavigation,
  FiSearch,
  FiTarget,
  FiTrendingUp,
} from "react-icons/fi";
import type {
  ContactMethod,
  NavItem,
  Project,
  Service,
  Skill,
  SocialLink,
  Stat,
  Testimonial,
} from "@/types/portfolio";

export const navItems: NavItem[] = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Services", href: "#services" },
  { label: "Contact", href: "#contact" },
];

export const socialLinks: SocialLink[] = [
  { label: "GitHub", href: "https://github.com/", icon: FiGithub },
  { label: "LinkedIn", href: "https://linkedin.com/", icon: FiLinkedin },
  { label: "Resume", href: "/resume.pdf", icon: FiBriefcase },
];

export const services: Service[] = [
  {
    title: "Website Development",
    description:
      "High-performance websites built with conversion strategy, clean architecture, and premium responsive interfaces.",
    icon: FiCode,
    accent: "blue",
  },
  {
    title: "Google Ads Management",
    description:
      "Campaign structures, landing-page alignment, tracking, and optimization for profitable lead generation.",
    icon: FiTarget,
    accent: "purple",
  },
  {
    title: "Google Maps SEO",
    description:
      "Local visibility systems that improve map rankings, calls, direction requests, and qualified local traffic.",
    icon: FiMapPin,
    accent: "green",
  },
  {
    title: "Local Business Growth",
    description:
      "A complete growth engine combining web, ads, analytics, content signals, and local search intent.",
    icon: FiTrendingUp,
    accent: "blue",
  },
];

export const skills: Skill[] = [
  { name: "React", level: 92, accent: "blue" },
  { name: "Next.js", level: 94, accent: "purple" },
  { name: "TypeScript", level: 88, accent: "blue" },
  { name: "Node.js", level: 84, accent: "green" },
  { name: "MongoDB", level: 82, accent: "green" },
  { name: "TailwindCSS", level: 93, accent: "blue" },
  { name: "Framer Motion", level: 86, accent: "purple" },
  { name: "SEO", level: 91, accent: "green" },
  { name: "Google Ads", level: 95, accent: "purple" },
];

export const projects: Project[] = [
  {
    title: "Medical Clinic Website",
    description:
      "A polished clinic experience with service funnels, booking CTAs, trust signals, and local SEO foundations.",
    techStack: ["Next.js", "TypeScript", "Tailwind", "SEO"],
    liveUrl: "https://example.com",
    sourceUrl: "https://github.com/",
    accent: "blue",
    visual: "medical",
  },
  {
    title: "Google Maps SEO Dashboard",
    description:
      "An analytics dashboard for rankings, calls, reviews, business profile activity, and location performance.",
    techStack: ["React", "Charts", "Maps API", "Node.js"],
    liveUrl: "https://example.com",
    sourceUrl: "https://github.com/",
    accent: "green",
    visual: "maps",
  },
  {
    title: "Local Business Growth Platform",
    description:
      "A campaign command center for offers, lead sources, landing pages, follow-up, and ROI visibility.",
    techStack: ["Next.js", "MongoDB", "Framer", "Ads"],
    liveUrl: "https://example.com",
    sourceUrl: "https://github.com/",
    accent: "purple",
    visual: "growth",
  },
  {
    title: "SaaS Admin Dashboard",
    description:
      "A premium SaaS control room with modular cards, team workflows, revenue insights, and crisp UX states.",
    techStack: ["React", "TypeScript", "Tailwind", "API"],
    liveUrl: "https://example.com",
    sourceUrl: "https://github.com/",
    accent: "blue",
    visual: "saas",
  },
  {
    title: "Real Estate Website",
    description:
      "A refined property discovery site with listing filters, neighborhood SEO, and high-intent inquiry paths.",
    techStack: ["Next.js", "CMS", "SEO", "Maps"],
    liveUrl: "https://example.com",
    sourceUrl: "https://github.com/",
    accent: "purple",
    visual: "realEstate",
  },
  {
    title: "Restaurant Booking System",
    description:
      "A conversion-focused restaurant site with table reservations, menu storytelling, and local search pages.",
    techStack: ["Next.js", "Node.js", "MongoDB", "SEO"],
    liveUrl: "https://example.com",
    sourceUrl: "https://github.com/",
    accent: "green",
    visual: "restaurant",
  },
];

export const stats: Stat[] = [
  { value: 50, suffix: "+", label: "Projects Completed", animated: true },
  { value: 100, suffix: "+", label: "Happy Clients", animated: true },
  { value: 5, suffix: "+", label: "Years Experience", animated: true },
  { value: "Top Rated", label: "Freelancer" },
];

export const testimonials: Testimonial[] = [
  {
    quote:
      "Mostafa rebuilt our clinic website and connected it with ads in a way that finally made patient leads predictable.",
    name: "Dr. Karim Hassan",
    role: "Founder",
    company: "Nile Care Clinic",
  },
  {
    quote:
      "Our Google Maps visibility changed fast. Calls increased, reviews became organized, and our local pages started converting.",
    name: "Mariam Adel",
    role: "Marketing Lead",
    company: "Urban Dental Studio",
  },
  {
    quote:
      "He thinks beyond pixels. The platform looked premium, loaded quickly, and gave us the reporting we needed every week.",
    name: "Omar Khaled",
    role: "Operations Manager",
    company: "Prime Local Growth",
  },
];

export const contactMethods: ContactMethod[] = [
  { label: "Email", value: "hello@mostafaahmed.dev", href: "mailto:hello@mostafaahmed.dev", icon: FiMail },
  { label: "WhatsApp", value: "+20 100 000 0000", href: "https://wa.me/201000000000", icon: FiMessageCircle },
  { label: "LinkedIn", value: "linkedin.com/in/mostafa-ahmed", href: "https://linkedin.com/", icon: FiLinkedin },
  { label: "GitHub", value: "github.com/mostafa-ahmed", href: "https://github.com/", icon: FiGithub },
];

export const heroChips = ["React", "Next.js", "TypeScript", "Node.js", "MongoDB", "TailwindCSS"];

export const aboutHighlights = [
  {
    title: "Performance-first builds",
    description: "Every interface is planned for speed, clarity, accessibility, and measurable conversion.",
    icon: FiGlobe,
  },
  {
    title: "Search intent strategy",
    description: "Technical SEO, local pages, and Google Maps signals are built into the growth system.",
    icon: FiSearch,
  },
  {
    title: "Full-funnel visibility",
    description: "Google Ads, tracking, landing pages, and analytics work together instead of living in silos.",
    icon: FiBarChart2,
  },
  {
    title: "Local acquisition",
    description: "Campaigns are tuned for real actions: calls, appointments, bookings, messages, and visits.",
    icon: FiNavigation,
  },
];
