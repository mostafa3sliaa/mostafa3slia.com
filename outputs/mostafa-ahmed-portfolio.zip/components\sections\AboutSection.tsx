"use client";

import { motion } from "framer-motion";
import { GlassCard } from "@/components/ui/GlassCard";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { aboutHighlights } from "@/data/portfolio";
import { fadeUp, staggerContainer } from "@/lib/motion";

export function AboutSection() {
  return (
    <section id="about" className="py-24 sm:py-28">
      <div className="section-shell">
        <SectionHeader
          eyebrow="About"
          title="A growth-minded developer for brands that need more than a website."
          description="Mostafa combines frontend engineering, paid acquisition, and local search strategy into one focused system for measurable business growth."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="grid gap-4 md:grid-cols-2 xl:grid-cols-4"
        >
          {aboutHighlights.map(({ title, description, icon: Icon }) => (
            <motion.div key={title} variants={fadeUp}>
              <GlassCard className="h-full">
                <span className="mb-5 grid size-11 place-items-center rounded-[8px] border border-white/12 bg-white/[0.06] text-blue-200">
                  <Icon aria-hidden className="size-5" />
                </span>
                <h3 className="text-lg font-semibold text-white">{title}</h3>
                <p className="mt-3 text-sm leading-6 text-gray-400">{description}</p>
              </GlassCard>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
