"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { navItems, socialLinks } from "@/data/portfolio";
import { cn } from "@/lib/utils";

export function Header() {
  const [active, setActive] = useState("#home");

  useEffect(() => {
    const sections = navItems
      .map((item) => document.querySelector(item.href))
      .filter((section): section is Element => Boolean(section));

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

        if (visible?.target.id) {
          setActive(`#${visible.target.id}`);
        }
      },
      { rootMargin: "-20% 0px -55% 0px", threshold: [0.2, 0.45, 0.7] },
    );

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  return (
    <motion.header
      initial={{ y: -32, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.21, 1, 0.21, 1] }}
      className="fixed inset-x-0 top-0 z-50 border-b border-white/8 bg-black/30 backdrop-blur-2xl"
    >
      <div className="section-shell flex min-h-20 items-center justify-between gap-4">
        <Link href="#home" className="focus-ring group flex items-center gap-3 rounded-[8px]">
          <span className="relative grid size-11 place-items-center overflow-hidden rounded-[8px] border border-white/12 bg-white/[0.06] text-sm font-black text-white shadow-2xl shadow-blue-500/10">
            <span className="absolute inset-0 bg-gradient-to-br from-white/18 via-transparent to-blue-400/18 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
            <span className="relative">MA</span>
          </span>
          <span className="hidden text-sm font-semibold text-white sm:block">Mostafa Ahmed</span>
        </Link>

        <nav className="hidden rounded-full border border-white/12 bg-white/[0.055] p-1 shadow-2xl shadow-black/30 backdrop-blur-2xl lg:flex">
          {navItems.map((item) => {
            const isActive = active === item.href;

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "focus-ring relative rounded-full px-4 py-2 text-sm font-medium transition-colors",
                  isActive ? "text-white" : "text-gray-400 hover:text-white",
                )}
              >
                {isActive ? (
                  <motion.span
                    layoutId="active-nav"
                    className="absolute inset-0 rounded-full border border-white/12 bg-white/10 shadow-[0_0_32px_rgba(96,165,250,0.18)]"
                    transition={{ type: "spring", stiffness: 360, damping: 32 }}
                  />
                ) : null}
                <span className="relative">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          {socialLinks.map(({ href, label, icon: Icon }) => (
            <motion.a
              key={label}
              href={href}
              target={href.startsWith("http") ? "_blank" : undefined}
              rel={href.startsWith("http") ? "noreferrer" : undefined}
              title={label}
              whileHover={{ y: -2, scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
              className="focus-ring inline-flex min-h-10 items-center gap-2 rounded-[8px] border border-white/12 bg-white/[0.055] px-3 text-sm font-medium text-gray-300 shadow-xl shadow-black/20 backdrop-blur-xl transition hover:border-blue-300/25 hover:text-white hover:shadow-blue-500/10"
            >
              <Icon aria-hidden className="size-4" />
              <span className="hidden xl:inline">{label}</span>
            </motion.a>
          ))}
        </div>
      </div>

      <div className="section-shell no-scrollbar flex gap-2 overflow-x-auto pb-3 lg:hidden">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "focus-ring shrink-0 rounded-full border px-4 py-2 text-sm transition",
              active === item.href
                ? "border-blue-300/30 bg-blue-400/10 text-white"
                : "border-white/10 bg-white/[0.04] text-gray-400",
            )}
          >
            {item.label}
          </Link>
        ))}
      </div>
    </motion.header>
  );
}
