import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://mostafa-ahmed.dev"),
  title: {
    default: "Mostafa Ahmed | Web Developer, Google Ads Expert, Google Maps SEO",
    template: "%s | Mostafa Ahmed",
  },
  description:
    "Premium personal portfolio for Mostafa Ahmed, a web developer, Google Ads expert, and Google Maps SEO specialist helping local businesses grow online.",
  keywords: [
    "Mostafa Ahmed",
    "Web Developer",
    "Google Ads Expert",
    "Google Maps SEO",
    "Local SEO",
    "Next.js Developer",
    "Portfolio",
  ],
  authors: [{ name: "Mostafa Ahmed" }],
  creator: "Mostafa Ahmed",
  openGraph: {
    title: "Mostafa Ahmed | Web Developer, Google Ads Expert, Google Maps SEO",
    description:
      "High-converting websites, profitable Google Ads campaigns, and Google Maps SEO for doctors, businesses, and local brands.",
    url: "https://mostafa-ahmed.dev",
    siteName: "Mostafa Ahmed Portfolio",
    images: [
      {
        url: "/images/mostafa-portrait.png",
        width: 1200,
        height: 1200,
        alt: "Mostafa Ahmed professional portrait",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Mostafa Ahmed | Web Developer, Google Ads Expert, Google Maps SEO",
    description:
      "High-converting websites, profitable Google Ads campaigns, and Google Maps SEO for local brands.",
    images: ["/images/mostafa-portrait.png"],
  },
  icons: {
    icon: "/favicon.svg",
  },
};

export const viewport: Viewport = {
  themeColor: "#050505",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
